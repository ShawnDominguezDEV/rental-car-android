package edu.txstate.sdd65.rentalcarapp;

import org.json.JSONObject;

public class RentalCar {
    private int id;
    private String name;
    private String brand;
    private String color;
    private double cost;
    private String url;

    public RentalCar(){
    }

    public RentalCar (JSONObject object){
        try {
            this.id = object.getInt("Id");
            this.name = object.getString("Name");
            this.brand = object.getString("Brand");
            this.color = object.getString("Color");
            this.cost = object.getDouble("Cost");
            this.url = object.getString("Url");
        }catch (Exception ex){ex.printStackTrace();}


    }
    public RentalCar(int id, String name, String brand, String color, double cost, String url){
        this.id = id;
        this.name = name;
        this.brand = brand;
        this.color = color;
        this.cost = cost;
        this.url = url;
    }

    public int getId() {return id;}

    public void setId(int id) {this.id = id;}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getColor(){return color;}

    public void setColor(String color){this.color = color;}

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public String toString() {return this.name;}
}
